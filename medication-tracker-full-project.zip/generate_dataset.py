import csv
import json
import random
from datetime import datetime, timedelta

# Base 30 medicines provided by the user
BASE_MEDICINES = [
    {"medicine_id": 1, "name": "Metformin", "generic_name": "Metformin HCl", "strength": "500 mg", "form": "Tablet", "category": "Antidiabetic", "condition_group": "Type 2 Diabetes"},
    {"medicine_id": 2, "name": "Glimepiride", "generic_name": "Glimepiride", "strength": "2 mg", "form": "Tablet", "category": "Antidiabetic", "condition_group": "Type 2 Diabetes"},
    {"medicine_id": 3, "name": "Sitagliptin", "generic_name": "Sitagliptin", "strength": "50 mg", "form": "Tablet", "category": "Antidiabetic", "condition_group": "Type 2 Diabetes"},
    {"medicine_id": 4, "name": "Insulin Glargine", "generic_name": "Insulin Glargine", "strength": "10 units", "form": "Injection", "category": "Antidiabetic", "condition_group": "Type 2 Diabetes"},
    {"medicine_id": 5, "name": "Amlodipine", "generic_name": "Amlodipine", "strength": "5 mg", "form": "Tablet", "category": "Antihypertensive", "condition_group": "Hypertension"},
    {"medicine_id": 6, "name": "Telmisartan", "generic_name": "Telmisartan", "strength": "40 mg", "form": "Tablet", "category": "Antihypertensive", "condition_group": "Hypertension"},
    {"medicine_id": 7, "name": "Losartan", "generic_name": "Losartan", "strength": "50 mg", "form": "Tablet", "category": "Antihypertensive", "condition_group": "Hypertension"},
    {"medicine_id": 8, "name": "Metoprolol", "generic_name": "Metoprolol", "strength": "25 mg", "form": "Tablet", "category": "Beta Blocker", "condition_group": "Hypertension"},
    {"medicine_id": 9, "name": "Levothyroxine", "generic_name": "Levothyroxine", "strength": "50 mcg", "form": "Tablet", "category": "Thyroid", "condition_group": "Hypothyroidism"},
    {"medicine_id": 10, "name": "Salbutamol Inhaler", "generic_name": "Salbutamol", "strength": "100 mcg", "form": "Inhaler", "category": "Bronchodilator", "condition_group": "Asthma"},
    {"medicine_id": 11, "name": "Montelukast", "generic_name": "Montelukast", "strength": "10 mg", "form": "Tablet", "category": "Antiasthmatic", "condition_group": "Asthma"},
    {"medicine_id": 12, "name": "Budesonide Inhaler", "generic_name": "Budesonide", "strength": "200 mcg", "form": "Inhaler", "category": "Corticosteroid", "condition_group": "Asthma"},
    {"medicine_id": 13, "name": "Atorvastatin", "generic_name": "Atorvastatin", "strength": "10 mg", "form": "Tablet", "category": "Statin", "condition_group": "High Cholesterol"},
    {"medicine_id": 14, "name": "Rosuvastatin", "generic_name": "Rosuvastatin", "strength": "10 mg", "form": "Tablet", "category": "Statin", "condition_group": "High Cholesterol"},
    {"medicine_id": 15, "name": "Aspirin", "generic_name": "Aspirin", "strength": "75 mg", "form": "Tablet", "category": "Antiplatelet", "condition_group": "Heart Disease"},
    {"medicine_id": 16, "name": "Clopidogrel", "generic_name": "Clopidogrel", "strength": "75 mg", "form": "Tablet", "category": "Antiplatelet", "condition_group": "Heart Disease"},
    {"medicine_id": 17, "name": "Ramipril", "generic_name": "Ramipril", "strength": "5 mg", "form": "Capsule", "category": "ACE Inhibitor", "condition_group": "Heart Disease"},
    {"medicine_id": 18, "name": "Ibuprofen", "generic_name": "Ibuprofen", "strength": "400 mg", "form": "Tablet", "category": "NSAID", "condition_group": "Arthritis"},
    {"medicine_id": 19, "name": "Diclofenac", "generic_name": "Diclofenac", "strength": "50 mg", "form": "Tablet", "category": "NSAID", "condition_group": "Arthritis"},
    {"medicine_id": 20, "name": "Calcium + Vitamin D3", "generic_name": "Calcium Carbonate", "strength": "500 mg", "form": "Tablet", "category": "Supplement", "condition_group": "Arthritis"},
    {"medicine_id": 21, "name": "Ferrous Sulfate", "generic_name": "Ferrous Sulfate", "strength": "200 mg", "form": "Tablet", "category": "Iron Supplement", "condition_group": "Anemia"},
    {"medicine_id": 22, "name": "Folic Acid", "generic_name": "Folic Acid", "strength": "5 mg", "form": "Tablet", "category": "Vitamin", "condition_group": "Anemia"},
    {"medicine_id": 23, "name": "Vitamin B12", "generic_name": "Methylcobalamin", "strength": "1500 mcg", "form": "Tablet", "category": "Vitamin", "condition_group": "Anemia"},
    {"medicine_id": 24, "name": "Sertraline", "generic_name": "Sertraline", "strength": "50 mg", "form": "Tablet", "category": "Antidepressant", "condition_group": "Depression/Anxiety"},
    {"medicine_id": 25, "name": "Escitalopram", "generic_name": "Escitalopram", "strength": "10 mg", "form": "Tablet", "category": "Antidepressant", "condition_group": "Depression/Anxiety"},
    {"medicine_id": 26, "name": "Levetiracetam", "generic_name": "Levetiracetam", "strength": "500 mg", "form": "Tablet", "category": "Anticonvulsant", "condition_group": "Epilepsy"},
    {"medicine_id": 27, "name": "Pantoprazole", "generic_name": "Pantoprazole", "strength": "40 mg", "form": "Tablet", "category": "Antacid/PPI", "condition_group": "General"},
    {"medicine_id": 28, "name": "Cetirizine", "generic_name": "Cetirizine", "strength": "10 mg", "form": "Tablet", "category": "Antihistamine", "condition_group": "General"},
    {"medicine_id": 29, "name": "Paracetamol", "generic_name": "Paracetamol", "strength": "500 mg", "form": "Tablet", "category": "Analgesic", "condition_group": "General"},
    {"medicine_id": 30, "name": "Multivitamin", "generic_name": "Multivitamin", "strength": "1 tab", "form": "Tablet", "category": "Supplement", "condition_group": "General"},
]

FIRST_NAMES_MALE = ["Arthur", "Harold", "Robert", "James", "William", "Richard", "Thomas", "Charles", "Walter", "George", "David", "Joseph", "Frank", "Edward", "Raymond", "Donald", "Henry", "Albert", "Paul", "Stanley", "Samuel", "Eugene", "Louis", "Leonard", "Harry"]
FIRST_NAMES_FEMALE = ["Eleanor", "Margaret", "Dorothy", "Evelyn", "Alice", "Ruth", "Florence", "Helen", "Martha", "Lillian", "Beatrice", "Clara", "Mildred", "Frances", "Edna", "Grace", "Hazel", "Esther", "Gladys", "Virginia", "Josephine", "Marian", "Rose", "Bernice", "Norma"]
LAST_NAMES = ["Miller", "Johnson", "Williams", "Brown", "Jones", "Davis", "Wilson", "Taylor", "Clark", "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Wood", "Bennett", "Gray", "Watson", "Brooks", "Kelly", "Sanders", "Price", "Baker"]

TIMINGS = [
    {"slot": "Morning", "time": "08:00", "food": "After Breakfast"},
    {"slot": "Morning", "time": "07:30", "food": "Before Breakfast"},
    {"slot": "Afternoon", "time": "13:00", "food": "After Lunch"},
    {"slot": "Evening", "time": "18:30", "food": "With Evening Snack"},
    {"slot": "Bedtime", "time": "21:30", "food": "Before Sleep"}
]

MISSED_REASONS = [
    "Forgot due to confusion / memory lapse",
    "Fell asleep / missed alarm",
    "Out of home without pillbox",
    "Felt nauseous / stomach upset",
    "Prescription ran out / refill pending",
    "Doctor advised temporary hold",
    "Misplaced medicine bottle",
    "Fasting for clinical tests"
]

def generate_patients(count=350):
    random.seed(42)
    patients = []
    for i in range(1, count + 1):
        pid = f"PAT-{1000 + i}"
        gender = "Female" if random.random() < 0.55 else "Male"
        first = random.choice(FIRST_NAMES_FEMALE if gender == "Female" else FIRST_NAMES_MALE)
        last = random.choice(LAST_NAMES)
        # Skew age towards elderly (60 - 89), with a smaller subset of 45-59
        if random.random() < 0.78:
            age = random.randint(62, 88)
        else:
            age = random.randint(45, 61)
            
        # Assign 2-5 chronic conditions/medications
        num_meds = random.randint(2, 5) if age >= 65 else random.randint(1, 3)
        assigned_meds = random.sample(BASE_MEDICINES, num_meds)
        
        # Patient's baseline adherence tendency (elderly often face barriers)
        baseline_adherence = random.choices([0.60, 0.75, 0.88, 0.95], weights=[0.15, 0.35, 0.35, 0.15])[0]
        
        patients.append({
            "patient_id": pid,
            "patient_name": f"{first} {last}",
            "age": age,
            "gender": gender,
            "assigned_meds": assigned_meds,
            "baseline_adherence": baseline_adherence,
            "has_caregiver": True if age > 75 or random.random() < 0.4 else False
        })
    return patients

def generate_15000_dataset(output_csv="medication_adherence_15000_records.csv", output_json="medication_adherence_15000_records.json"):
    patients = generate_patients(400)
    records = []
    
    start_date = datetime(2026, 6, 1)
    current_date = datetime(2026, 10, 24)
    total_days = (current_date - start_date).days
    
    random.seed(1337)
    record_id = 1
    
    # We will generate intake logs across the patient pool until we reach exactly 15,000 records
    while record_id <= 15000:
        patient = random.choice(patients)
        med = random.choice(patient["assigned_meds"])
        
        # Pick a date within past months
        days_offset = random.randint(0, total_days)
        log_date = start_date + timedelta(days=days_offset)
        log_date_str = log_date.strftime("%Y-%m-%d")
        
        # Timing slot
        timing = random.choice(TIMINGS)
        scheduled_time = timing["time"]
        slot = timing["slot"]
        food_instruction = timing["food"]
        
        # Determine adherence outcome based on patient profile & age
        adherence_chance = patient["baseline_adherence"]
        if patient["age"] > 75:
            adherence_chance -= 0.05
        if not patient["has_caregiver"]:
            adherence_chance -= 0.04
        adherence_chance = max(0.40, min(0.98, adherence_chance))
        
        roll = random.random()
        if roll < adherence_chance:
            # Taken on time or with slight delay
            if random.random() < 0.72:
                status = "Taken"
                delay = random.randint(-10, 25)
                missed_reason = "None"
            else:
                status = "Delayed"
                delay = random.randint(30, 150)
                missed_reason = "None"
                
            sched_dt = datetime.strptime(f"{log_date_str} {scheduled_time}", "%Y-%m-%d %H:%M")
            actual_dt = sched_dt + timedelta(minutes=delay)
            actual_time_str = actual_dt.strftime("%H:%M")
            caregiver_alert = "No Alert Needed"
        elif roll < adherence_chance + 0.12:
            status = "Skipped"
            actual_time_str = "None"
            delay = 0
            missed_reason = random.choice(MISSED_REASONS[3:])
            caregiver_alert = "Notification Sent" if patient["has_caregiver"] else "Logged in App"
        else:
            status = "Missed"
            actual_time_str = "None"
            delay = 0
            missed_reason = random.choice(MISSED_REASONS[:3])
            caregiver_alert = "Urgent Notification" if patient["has_caregiver"] else "Reminder Repeated"
            
        # Dose amount
        dose_amount = f"1 {med['form']}" if med["form"] != "Inhaler" and med["form"] != "Injection" else ("2 Puffs" if med["form"] == "Inhaler" else "10 Units")
        
        record = {
            "record_id": record_id,
            "patient_id": patient["patient_id"],
            "patient_name": patient["patient_name"],
            "age": patient["age"],
            "gender": patient["gender"],
            "has_caregiver": "Yes" if patient["has_caregiver"] else "No",
            "medicine_id": med["medicine_id"],
            "medicine_name": med["name"],
            "generic_name": med["generic_name"],
            "strength": med["strength"],
            "form": med["form"],
            "dosage": dose_amount,
            "category": med["category"],
            "condition_group": med["condition_group"],
            "scheduled_date": log_date_str,
            "scheduled_time": scheduled_time,
            "time_of_day": slot,
            "food_instruction": food_instruction,
            "status": status,
            "actual_taken_time": actual_time_str,
            "delay_minutes": delay,
            "missed_reason": missed_reason,
            "caregiver_alert_status": caregiver_alert
        }
        
        records.append(record)
        record_id += 1

    # Save to CSV
    fieldnames = list(records[0].keys())
    with open(output_csv, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)
        
    # Save a lighter JSON or sample JSON
    with open(output_json, mode="w", encoding="utf-8") as f:
        json.dump(records, f, indent=2)

    # Also save a 500-sample JSON for super-fast frontend display
    with open("medication_adherence_sample_500.json", mode="w", encoding="utf-8") as f:
        json.dump(records[:500], f, indent=2)

    print(f"Successfully generated {len(records)} records in '{output_csv}' and '{output_json}'.")

if __name__ == "__main__":
    generate_15000_dataset()
