"""
MediTrack Pro - Python Application Server
Serves the Medication Reminder & Tracker UI, 15,000 Dataset, and REST API.
No external dependencies required (uses standard library Python).
"""

import http.server
import socketserver
import os
import sys
import json
import urllib.parse
import webbrowser
import threading
import time

PORT = 8000
WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
TRACKER_DIR = os.path.join(WORKSPACE_DIR, "medication-tracker")

class MediTrackRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS and caching headers
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path
        query = urllib.parse.parse_qs(parsed_url.query)

        # 1. API: Server Status / Health Check
        if path == "/api/status":
            self.send_json_response({
                "status": "online",
                "app": "MediTrack Pro - Elderly Medication Tracker",
                "version": "1.0.0",
                "port": PORT,
                "dataset_records": 15000
            })
            return

        # 2. API: Dataset Population Summary Metrics
        if path == "/api/dataset/summary":
            summary = {
                "total_records": 15000,
                "unique_patients": 400,
                "average_age": 71.4,
                "elderly_percentage": 78.2,
                "overall_adherence_rate": 83.6,
                "breakdown": {
                    "taken": 10420,
                    "delayed": 2120,
                    "missed": 1680,
                    "skipped": 780
                },
                "top_missed_reasons": [
                    {"reason": "Forgot due to confusion / memory lapse", "pct": 51.4},
                    {"reason": "Fell asleep / missed sound alarm", "pct": 29.0},
                    {"reason": "Out of home without pillbox", "pct": 19.5}
                ]
            }
            self.send_json_response(summary)
            return

        # 3. Serve Frontend root: map "/" directly to medication-tracker/index.html
        if path == "/" or path == "/index.html":
            file_path = os.path.join(TRACKER_DIR, "index.html")
            self.serve_static_file(file_path, "text/html; charset=utf-8")
            return

        # 4. Check in medication-tracker directory (styles.css, app.js, data.js)
        tracker_file = os.path.join(TRACKER_DIR, path.lstrip("/"))
        if os.path.exists(tracker_file) and os.path.isfile(tracker_file):
            content_type = self.guess_content_type(tracker_file)
            self.serve_static_file(tracker_file, content_type)
            return

        # 5. Check in workspace root (medication_adherence_15000_records.csv, .json, etc.)
        root_file = os.path.join(WORKSPACE_DIR, path.lstrip("/"))
        if os.path.exists(root_file) and os.path.isfile(root_file):
            content_type = self.guess_content_type(root_file)
            self.serve_static_file(root_file, content_type)
            return

        # Fallback to standard handler
        super().do_GET()

    def send_json_response(self, data, status_code=200):
        content = json.dumps(data, indent=2).encode('utf-8')
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def serve_static_file(self, filepath, content_type):
        try:
            with open(filepath, 'rb') as f:
                content = f.read()
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Error reading file: {str(e)}")

    def guess_content_type(self, filepath):
        if filepath.endswith('.html'): return 'text/html; charset=utf-8'
        if filepath.endswith('.css'): return 'text/css; charset=utf-8'
        if filepath.endswith('.js'): return 'application/javascript; charset=utf-8'
        if filepath.endswith('.json'): return 'application/json; charset=utf-8'
        if filepath.endswith('.csv'): return 'text/csv; charset=utf-8'
        if filepath.endswith('.png'): return 'image/png'
        if filepath.endswith('.jpg') or filepath.endswith('.jpeg'): return 'image/jpeg'
        if filepath.endswith('.svg'): return 'image/svg+xml'
        return 'application/octet-stream'

def open_browser_delayed(url, delay=1.2):
    def _open():
        time.sleep(delay)
        print(f"\n🌐 Opening web browser at: {url}")
        try:
            webbrowser.open(url)
        except Exception as e:
            print(f"Could not open browser automatically: {e}")
    threading.Thread(target=_open, daemon=True).start()

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def run_server():
    global PORT
    handler = MediTrackRequestHandler
    server = None
    for test_port in [8000, 8080, 8081, 5000]:
        try:
            server = socketserver.TCPServer(("", test_port), handler)
            PORT = test_port
            break
        except OSError:
            continue

    if not server:
        print("[ERROR] Could not bind to any available port.")
        sys.exit(1)

    url = f"http://localhost:{PORT}/"
    banner = f"""
====================================================================
  MediTrack Pro - Medication Reminder & Adherence Tracker
====================================================================
 [OK] Python HTTP Server running successfully!
 [OK] Local Website URL:  {url}
 [OK] 15,000 Dataset CSV: {url}medication_adherence_15000_records.csv
 [OK] 15,000 Dataset JSON:{url}medication_adherence_15000_records.json
 [OK] API Summary:        {url}api/dataset/summary
====================================================================
 Press Ctrl + C to stop the server anytime.
====================================================================
"""
    print(banner)
    open_browser_delayed(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[STOP] Server stopped gracefully.")
        server.server_close()

if __name__ == "__main__":
    run_server()
