# 💊 MediTrack Pro - Medication Reminder & Adherence Tracker

An intelligent, accessible Medication Reminder & Adherence Tracker designed specifically for elderly patients and chronic care management. Built with real-time audio chimes, voice speech synthesis, 7-day visual adherence charts, and a 15,000-record clinical dataset explorer.

---

## 🌟 Key Features

1. **Circadian Pillbox Timetable**:
   - Organizes daily regimen into Morning, Afternoon, Evening, and Bedtime slots.
   - Pre-loaded with 30 clinical medications (Metformin, Amlodipine, Levothyroxine, Inhalers, Statins, etc.).
   - Actions for **Mark as Taken**, **Snooze 15 Min**, and **Hear Instructions**.

2. **Elderly-Friendly Audio & Speech Assistance**:
   - **Web Audio API Synthesizer**: Generates gentle, harmonic chime tones without external audio assets.
   - **Web Speech API**: Speaks dose instructions clearly aloud (*"It is time to take your Metformin 500 mg after dinner"*).
   - **Senior High-Contrast Mode**: WCAG AAA compliant yellow/black high-contrast theme with jumbo buttons and large typography.

3. **Weekly Adherence Analytics & Visualizer**:
   - Interactive 7-day adherence bar chart (Monday to Sunday).
   - Circular SVG compliance status gauge and streak tracker.
   - Geriatric insights on missed dose patterns.

4. **15,000-Record Adherence Dataset**:
   - Realistic clinical cohort simulation covering 400 patients, ages 45–89 (78% elderly).
   - Tracks intake timestamps, delay minutes, missed reasons, and caregiver notifications.
   - Integrated search, filtering, and one-click CSV export.

5. **Self-Contained Python Server**:
   - Built-in `run_server.py` using Python's standard library with zero external dependencies.
   - REST API endpoints for health status and dataset analytics.

---

## 🚀 Quick Start

### 1. Run the Python Server
```bash
python run_server.py
```
This automatically starts the server and opens `http://localhost:8000/` in your default browser.

### 2. Generate or Regenerate the 15,000 Dataset
```bash
python generate_dataset.py
```

---

## 📁 Project Structure

```
├── medication-tracker/
│   ├── index.html        # Main responsive UI
│   ├── styles.css        # Emerald glassmorphism & senior accessibility theme
│   ├── app.js            # Core engine (Web Audio, Speech, LocalStorage, Charts)
│   └── data.js           # 30 base medicines & preset regimens
├── run_server.py         # Standard library Python HTTP & REST API server
├── generate_dataset.py   # Realistic 15,000 clinical record generator
├── medication_adherence_15000_records.csv   # 15,000-record CSV dataset (~3 MB)
├── medication_adherence_15000_records.json  # Full JSON dataset (~11 MB)
├── medication_adherence_sample_500.json    # Fast-load sample dataset
└── README.md
```

---

## 👤 Author
GitHub: [@mallikan929412-eng](https://github.com/mallikan929412-eng)
